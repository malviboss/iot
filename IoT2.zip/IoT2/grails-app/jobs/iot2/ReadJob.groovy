package iot2

import grails.transaction.Transactional
import groovy.json.JsonSlurper
import groovy.time.TimeCategory

import java.text.SimpleDateFormat
import java.security.MessageDigest
import grails.util.Environment


class ReadJob {
    def sensoreService
    def tipoMisuraService
    def avvisoService
    def misuraService
    static Long intervallo = 2000l
    //static Long delay = 20000
    static Long delay = 0l
    static triggers = {
        //simple repeatInterval: intervallo // execute job once UN'ORA
        simple name: 'simpleTrigger', startDelay: delay, repeatInterval: intervallo, repeatCount: -1
    }

    @Transactional
    def execute() {

        //println "job! ogni ${intervallo}"

        def datax = null// STRINGA DA LEGGERE


        //////////////

        try {

            def nonce
            def sessionID
            def password = "c8519a64522561ada7c4c08af3d6cf1663759c21"
            def noncePiuPassword
            def cookie
            def urlx = null;
            if (Environment.current == Environment.DEVELOPMENT) {
                urlx = "http://193.205.130.31:8080" // LOCALE
            } else if (Environment.current == Environment.TEST) {
                urlx = "http://193.205.130.31:8080" // LOCALE

                // insert Test environment specific code here
            } else if (Environment.current == Environment.PRODUCTION) {
                urlx = "http://192.168.111.240:8080" //REMOTO
            }
//def urlx = "http://192.168.111.240:8080" //REMOTO
// def urlx = "http://193.205.130.31:8080" // LOCALE


            def urlz = "${urlx}/zipato-web/v2/user/init"
            cookie = misuraService.leggiGateway(urlz)

            HashMap<String, String> jsonMap = new JsonSlurper().parse(new URL(urlz))

            jsonMap.each { k, v ->
                if (k == "jsessionid") {
                    sessionID = v
                    String session = sessionID.toString()


                }
                if (k == "nonce") {
                    nonce = v
                    noncePiuPassword = nonce + password
                    def messageDigest = MessageDigest.getInstance("SHA1")
                    messageDigest.update(noncePiuPassword.getBytes())
                    String token
                    def sha1Hex = new BigInteger(1, messageDigest.digest()).toString(16).padLeft(40, '0')

                    def urlSuccess = "${urlx}/zipato-web/v2/user/login?username=inmedioshostes@hotmail.com&token=${sha1Hex}"
                    def connessione2 = misuraService.leggiConnessione(urlSuccess, 'JSESSIONID', cookie)
                    if (connessione2) {
                        HashMap<String, String> json2 = new JsonSlurper().parse(new URL(urlSuccess))
                        json2.each { f, z ->
                            if (z) {
                                String urlToValidate = "${urlx}/zipato-web/v2/attributes/full?JSESSIONID=${sessionID}"
                                misuraService.leggiConnessione(urlToValidate, 'JSESSIONID', cookie)
                                String urlDaLeggere = "${urlx}/zipato-web/v2/attributes/values?update=false"

                                datax = new JsonSlurper().parse(new URL(urlDaLeggere))

                            }

                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace()
        }

        //////////////


        def uuid
        Boolean salvato = false

        if (datax != null) {
            for (it in datax) {
                def serviceName = it.keySet()
                it.each { k, v ->
                    if (k == "uuid") {
                        uuid = v
                    }
                    Date date = null
                    def valore = null
                    if (k == "value") {
                        // println "questo è un valore"
                        v.each { x, y ->
                            if (x == "timestamp") {
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
                                date = sdf.parse(y)
                                use(TimeCategory) {
                                    date = date + 2.hours
                                }

                            }
                            if (x == "value") {
                                valore = y

                            }


                        }


                        Misura misura = new Misura()

                        misura.data = date
                        misura.valore = valore.toString()

                        Sensore sensTrovato = null
                        //def listaSensori = sensoreService.trovaSensore(sensore)
                        def listaSensori = sensoreService.trovaSensoreUuid(uuid)
                        //TUTTI I SENSORI DEVONO ESISTERE!
                        if (!listaSensori.isEmpty()) {
                            if (listaSensori.size() == 1) {
                                for (Sensore sens : listaSensori) {
                                    sensTrovato = sens
                                    misura.tipoMisura = sens.tipoMisura
                                }
                            } else {
                                println("NON UNICO")
                            }

                        }
                        if (sensTrovato != null && misura.tipoMisura != null && misura.data != null && misura.valore != null) {
                            misura.sensore = sensTrovato
                            if (misuraService.trovaMisureDoppie(sensTrovato, misura.data, misura.valore)) {
                            } else {
                                //SE IMPOSTATO TEMPO CAMPIONAMENTO, NON SALVO SE NON E' PASSATO DETERMINATO TEMPO IN MILLISECONDI
                                Boolean tempoPassato = true
                                if (sensTrovato.tempoCampionamento != null) {
                                    Date nowDate = new Date()
                                    def timeInMillis = misura.data.time + sensTrovato.tempoCampionamento
                                    Date dateToCheck = new Date(timeInMillis)
                                    if (dateToCheck.after(nowDate)) {
                                        tempoPassato = false
                                    }

                                }
                                //SALVATAGGIO MISURA
                                if (tempoPassato) {
                                    //CONTROLLARE SE L'ULTIMA MISURA DEL SENSORE E' DELLO STESSO VALORE (SE DISCRETO!). SE LO E'.. NON SALVO
                                    Boolean misuraPrecedenteUguale = false
                                    if (misura.sensore.tipoMisura.dataType.tipo.equals("Boolean")) {
                                        Misura misuraPrecedente = misuraService.trovaUltimaMisura(misura.sensore, misura.valore)
                                        if (misuraPrecedente.valore.equals(misura.valore)) {
                                            misuraPrecedenteUguale = true
                                        }


                                    }
                                    if (!misuraPrecedenteUguale) {
                                        println("MISURA PRIMA DI ESSERE SALVATA ${misura.data}, ${misura.valore} , ${misura.sensore.nomeSensore}, ${misura.tipoMisura.nomeMisura}  ")
                                        misura.save(flush: true, failOnError: true)
                                        salvato = true
                                    }

                                    //CREAZIONE AVVISO STANDARD
                                    try {
                                        if (salvato && misura.tipoMisura.dataType.tipo.equals("Double")) {
                                            if (misura.valore.toDouble()) {
                                                Double ValoreDouble = misura.valore.toDouble()

                                                if (misura.sensore.max != null && misura.sensore.min != null && (ValoreDouble < misura.sensore.min || ValoreDouble > misura.sensore.max)) {

                                                    println("CREAZIONE AVVISO DOUBLE")
                                                    Avviso avviso = new Avviso()
                                                    avviso.sensore = sensTrovato
                                                    if (ValoreDouble < misura.sensore.min)
                                                        avviso.avviso = "sotto soglia minima"
                                                    else {
                                                        avviso.avviso = "sopra soglia massima"
                                                    }
                                                    avviso.descrizione = "poblema al sensore ${sensTrovato.nomeSensore} ,  tipo ${misura.tipoMisura.nomeMisura}, Misura: ${misura.valore}"
                                                    avviso.letto = false
                                                    // VERIFICARE SE LA FREQUENZA AVVISO E' RISPETTATA (DEFAULT 1)
                                                    if (misuraService.frequenzaAvviso(sensTrovato, misura))
                                                        avviso.save(flush: true, failOnError: true)
                                                    else
                                                        println "Avviso non salvato, non raggiunta soglia"
                                                }
                                            }

                                        } else if (salvato && misura.tipoMisura.dataType.tipo.equals("Boolean")) {

                                        } else if (salvato && misura.tipoMisura.dataType.tipo.equals("String")) {

                                        } else if (salvato && misura.tipoMisura.dataType.tipo.equals("Integer")) {
                                            if (misura.valore.toInteger()) {
                                                Integer valoreInt = misura.valore.toInteger()

                                                if (misura.sensore.max != null && misura.sensore.min != null && (valoreInt < misura.sensore.min || valoreInt > misura.sensore.max)) {

                                                    println("CREAZIONE AVVISO INTEGER")
                                                    Avviso avviso = new Avviso()
                                                    avviso.sensore = sensTrovato
                                                    if (valoreInt < misura.sensore.min)
                                                        avviso.avviso = "sotto soglia minima"
                                                    else {
                                                        avviso.avviso = "sopra soglia massima"
                                                    }
                                                    avviso.descrizione = "poblema al sensore ${sensTrovato.nomeSensore} ,  tipo ${misura.tipoMisura.nomeMisura} , Misura: ${misura.valore}"
                                                    avviso.letto = false
                                                    // VERIFICARE SE LA FREQUENZA AVVISO E' RISPETTATA (DEFAULT 1)
                                                    if (misuraService.frequenzaAvviso(sensTrovato, misura)) {
                                                        avviso.save(flush: true, failOnError: true)

                                                    } else
                                                        println "Avviso non salvato, non raggiunta soglia"

                                                }
                                            }

                                        }


                                    } catch (Exception e) {
                                        e.printStackTrace()
                                    }
                                    //CREAZIONE AVVISO PERSONALIZZATO
                                    try {
                                        if (salvato && misura.tipoMisura.dataType.tipo.equals("Double")) {
                                            if (misura.valore.toDouble()) {
                                                Double valoreDouble = misura.valore.toDouble()
                                                List<SogliaAvviso> soglie = avvisoService.trovaSoglie(misura.sensore)

                                                for (SogliaAvviso soglia : soglie) {
                                                    if (valoreDouble < soglia.valorePersonalizzato) {

                                                        println("CREAZIONE AVVISO PERSONALIZZATO DOUBLE")
                                                        Avviso avviso = new Avviso()
                                                        avviso.sensore = sensTrovato

                                                        avviso.avviso = "${soglia.descrizione}"
                                                        avviso.descrizione = "poblema al sensore ${sensTrovato.nomeSensore} ,  tipo ${misura.tipoMisura.nomeMisura}, Misura: ${misura.valore}"
                                                        avviso.letto = false
                                                        // VERIFICARE SE LA FREQUENZA AVVISO E' RISPETTATA (DEFAULT 1)
                                                        if (misuraService.frequenzaAvviso(sensTrovato, misura))
                                                            avviso.save(flush: true, failOnError: true)
                                                        else
                                                            println "Avviso non salvato, non raggiunta soglia"
                                                    }

                                                }


                                            }

                                        } else if (salvato && misura.tipoMisura.dataType.tipo.equals("Boolean")) {
                                            Boolean valoreBool = misura.valore.toBoolean()
                                            List<SogliaAvviso> soglie = avvisoService.trovaSoglie(sensTrovato)

                                            for (SogliaAvviso soglia : soglie) {
                                                def sogliaReboot = null
                                                if (soglia.valorePersonalizzato == 0d) {
                                                    sogliaReboot = false
                                                } else if (soglia.valorePersonalizzato == 1) {
                                                    sogliaReboot = true
                                                }
                                                if (sogliaReboot != null && valoreBool == sogliaReboot) {

                                                    println("CREAZIONE AVVISO PERSONALIZZATO BOOLEAN")
                                                    Avviso avviso = new Avviso()
                                                    avviso.sensore = sensTrovato

                                                    avviso.avviso = "${soglia.descrizione}"
                                                    avviso.descrizione = "poblema al sensore ${sensTrovato.nomeSensore} ,  tipo ${misura.tipoMisura.nomeMisura}, Misura: ${misura.valore}"
                                                    avviso.letto = false
                                                    // NON ESISTE SOGLIA NEI BOOLEAN
                                                    avviso.save(flush: true, failOnError: true)

                                                }


                                            }


                                        } else if (salvato && misura.tipoMisura.dataType.tipo.equals("Integer")) {
                                            if (misura.valore.toInteger()) {
                                                Integer valoreInteger = misura.valore.toInteger()
                                                List<SogliaAvviso> soglie = avvisoService.trovaSoglie(misura.sensore)

                                                for (SogliaAvviso soglia : soglie) {
                                                    if (valoreInteger < soglia.valorePersonalizzato) {

                                                        println("CREAZIONE AVVISO PERSONALIZZATO INTEGER")
                                                        Avviso avviso = new Avviso()
                                                        avviso.sensore = sensTrovato

                                                        avviso.avviso = "${soglia.descrizione}"
                                                        avviso.descrizione = "poblema al sensore ${sensTrovato.nomeSensore} ,  tipo ${misura.tipoMisura.nomeMisura}, Misura: ${misura.valore}"
                                                        avviso.letto = false
                                                        // VERIFICARE SE LA FREQUENZA AVVISO E' RISPETTATA (DEFAULT 1)
                                                        if (misuraService.frequenzaAvviso(sensTrovato, misura))
                                                            avviso.save(flush: true, failOnError: true)
                                                        else
                                                            println "Avviso non salvato, non raggiunta soglia"
                                                    }

                                                }


                                            }

                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace()
                                    }
                                }
                            }
                        }


                    }


                }
            }
        }


    }


}