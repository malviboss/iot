package iot2



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class TipoMisuraController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond TipoMisura.list(params), model:[tipoMisuraInstanceCount: TipoMisura.count()]
    }

    def show(TipoMisura tipoMisuraInstance) {
        respond tipoMisuraInstance
    }

    def create() {
        respond new TipoMisura(params)
    }

    @Transactional
    def save(TipoMisura tipoMisuraInstance) {
        if (tipoMisuraInstance == null) {
            notFound()
            return
        }

        if (tipoMisuraInstance.hasErrors()) {
            respond tipoMisuraInstance.errors, view:'create'
            return
        }

        tipoMisuraInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'tipoMisura.label', default: 'TipoMisura'), tipoMisuraInstance.id])
                redirect tipoMisuraInstance
            }
            '*' { respond tipoMisuraInstance, [status: CREATED] }
        }
    }

    def edit(TipoMisura tipoMisuraInstance) {
        respond tipoMisuraInstance
    }

    @Transactional
    def update(TipoMisura tipoMisuraInstance) {
        if (tipoMisuraInstance == null) {
            notFound()
            return
        }

        if (tipoMisuraInstance.hasErrors()) {
            respond tipoMisuraInstance.errors, view:'edit'
            return
        }

        tipoMisuraInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'TipoMisura.label', default: 'TipoMisura'), tipoMisuraInstance.id])
                redirect tipoMisuraInstance
            }
            '*'{ respond tipoMisuraInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(TipoMisura tipoMisuraInstance) {

        if (tipoMisuraInstance == null) {
            notFound()
            return
        }

        tipoMisuraInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'TipoMisura.label', default: 'TipoMisura'), tipoMisuraInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'tipoMisura.label', default: 'TipoMisura'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
