package iot2

import jxl.Workbook
import jxl.write.Label
import jxl.write.WritableSheet
import jxl.write.WritableWorkbook
import sun.management.Sensor

import javax.swing.JOptionPane
import java.text.SimpleDateFormat

import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class SensoreController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond Sensore.list(params), model:[sensoreInstanceCount: Sensore.count()]
    }

    def exportCSV(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond Sensore.list(params), model:[sensoreInstanceCount: Sensore.count()]
    }


    def show(Sensore sensoreInstance) {
        respond sensoreInstance
    }

    def create() {
        respond new Sensore(params)
    }

    def esporta(Sensori sensori) {
        List<Sensore> sensors = sensori
        if (sensors.size() == 0) {
            println("vuoto")
        } else {

            for (Sensore sensore : sensori) {
                println(sensore.toString())
            }
        }
    }

    @Transactional
    def save(Sensore sensoreInstance) {
        if (sensoreInstance == null) {
            notFound()
            return
        }

        if (sensoreInstance.hasErrors()) {
            respond sensoreInstance.errors, view:'create'
            return
        }

        sensoreInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'sensore.label', default: 'Sensore'), sensoreInstance.id])
                redirect sensoreInstance
            }
            '*' { respond sensoreInstance, [status: CREATED] }
        }
    }

    def edit(Sensore sensoreInstance) {
        respond sensoreInstance
    }

    @Transactional
    def update(Sensore sensoreInstance) {
        if (sensoreInstance == null) {
            notFound()
            return
        }

        if (sensoreInstance.hasErrors()) {
            respond sensoreInstance.errors, view:'edit'
            return
        }

        sensoreInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'Sensore.label', default: 'Sensore'), sensoreInstance.id])
                redirect sensoreInstance
            }
            '*'{ respond sensoreInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(Sensore sensoreInstance) {

        if (sensoreInstance == null) {
            notFound()
            return
        }



        sensoreInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'Sensore.label', default: 'Sensore'), sensoreInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }

    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'sensore.label', default: 'Sensore'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }

    Boolean compareMaxMin(Double max, Double min){
        if (max!=null && min !=null){
        if (min<max){
            return false
        } else if (max > min){
            return false
        } else {
            return true
        }
        } else {
            return true
        }
    }

    def downloadSampleExcel(Sensore sensore) {
        response.setContentType('application/vnd.ms-excel')
        response.setHeader('Content-Disposition', 'Attachment;Filename="misure.xls"')
        WritableWorkbook workbook = Workbook.createWorkbook(response.outputStream)
        WritableSheet sheet1 = workbook.createSheet("Misure", 0)
        List<Sensore> listaSensori = Sensore.findAll()

            sheet1.addCell(new Label(1, 0, sensore.toString()))
            def counterMisure = 1
            List<Misura> listaMisure = Misura.findAllBySensore(sensore)
            for (Misura misura : listaMisure) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
                sheet1.addCell(new Label(1, counterMisure, sdf.format(misura.data) + ";" + misura.valore))
                counterMisure++
            }


        workbook.write();
        workbook.close();
    }
}

class Sensori {
    List<Sensore> sensori
}