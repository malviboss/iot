package iot2



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class AvvisoController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond Avviso.list(params), model:[avvisoInstanceCount: Avviso.count()]
    }

    def indexNonLetti(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond Avviso.findAllByLetto(false)
    }

    def show(Avviso avvisoInstance) {
        respond avvisoInstance
    }

    def create() {
        respond new Avviso(params)
    }

    @Transactional
    def save(Avviso avvisoInstance) {
        if (avvisoInstance == null) {
            notFound()
            return
        }

        if (avvisoInstance.hasErrors()) {
            respond avvisoInstance.errors, view:'create'
            return
        }

        avvisoInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'avviso.label', default: 'Avviso'), avvisoInstance.id])
                redirect avvisoInstance
            }
            '*' { respond avvisoInstance, [status: CREATED] }
        }
    }

    def edit(Avviso avvisoInstance) {
        respond avvisoInstance
    }

    @Transactional
    def update(Avviso avvisoInstance) {
        if (avvisoInstance == null) {
            notFound()
            return
        }

        if (avvisoInstance.hasErrors()) {
            respond avvisoInstance.errors, view:'edit'
            return
        }

        avvisoInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'Avviso.label', default: 'Avviso'), avvisoInstance.id])
                redirect avvisoInstance
            }
            '*'{ respond avvisoInstance, [status: OK] }
        }
    }
    @Transactional
    def updatex(Avvisi avviso) {
        // this is naive and doesn't deal with things like error
        // handling but is intentially simplified to focus on the
        // question at hand...

        avviso.avvisi*.save()

        redirect action: 'indexNonLetti'
    }

    @Transactional
    def delete(Avviso avvisoInstance) {

        if (avvisoInstance == null) {
            notFound()
            return
        }

        avvisoInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'Avviso.label', default: 'Avviso'), avvisoInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'avviso.label', default: 'Avviso'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }



}

class Avvisi {
    List<Avviso> avvisi
}
