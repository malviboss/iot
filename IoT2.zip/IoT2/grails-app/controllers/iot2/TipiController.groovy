package iot2



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class TipiController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond Tipi.list(params), model:[tipiInstanceCount: Tipi.count()]
    }

    def show(Tipi tipiInstance) {
        respond tipiInstance
    }

    def create() {
        respond new Tipi(params)
    }

    @Transactional
    def save(Tipi tipiInstance) {
        if (tipiInstance == null) {
            notFound()
            return
        }

        if (tipiInstance.hasErrors()) {
            respond tipiInstance.errors, view:'create'
            return
        }

        tipiInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'tipi.label', default: 'Tipi'), tipiInstance.id])
                redirect tipiInstance
            }
            '*' { respond tipiInstance, [status: CREATED] }
        }
    }

    def edit(Tipi tipiInstance) {
        respond tipiInstance
    }

    @Transactional
    def update(Tipi tipiInstance) {
        if (tipiInstance == null) {
            notFound()
            return
        }

        if (tipiInstance.hasErrors()) {
            respond tipiInstance.errors, view:'edit'
            return
        }

        tipiInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'Tipi.label', default: 'Tipi'), tipiInstance.id])
                redirect tipiInstance
            }
            '*'{ respond tipiInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(Tipi tipiInstance) {

        if (tipiInstance == null) {
            notFound()
            return
        }

        tipiInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'Tipi.label', default: 'Tipi'), tipiInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'tipi.label', default: 'Tipi'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
