package iot2

import java.text.SimpleDateFormat

import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional
import jxl.Workbook
import jxl.write.Label
import jxl.write.WritableSheet
import jxl.write.WritableWorkbook

@Transactional(readOnly = true)
class MisuraController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond Misura.list(params), model:[misuraInstanceCount: Misura.count()]
    }

    def show(Misura misuraInstance) {
        respond misuraInstance
    }

    def create() {
        respond new Misura(params)
    }



    @Transactional
    def save(Misura misuraInstance) {
        if (misuraInstance == null) {
            notFound()
            return
        }

        if (misuraInstance.hasErrors()) {
            respond misuraInstance.errors, view:'create'
            return
        }

        misuraInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'misura.label', default: 'Misura'), misuraInstance.id])
                redirect misuraInstance
            }
            '*' { respond misuraInstance, [status: CREATED] }
        }
    }

    def edit(Misura misuraInstance) {
        respond misuraInstance
    }

    @Transactional
    def update(Misura misuraInstance) {
        if (misuraInstance == null) {
            notFound()
            return
        }

        if (misuraInstance.hasErrors()) {
            respond misuraInstance.errors, view:'edit'
            return
        }

        misuraInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'Misura.label', default: 'Misura'), misuraInstance.id])
                redirect misuraInstance
            }
            '*'{ respond misuraInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(Misura misuraInstance) {

        if (misuraInstance == null) {
            notFound()
            return
        }

        misuraInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'Misura.label', default: 'Misura'), misuraInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'misura.label', default: 'Misura'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }


    def list(Sensore sensor) {
        [misure: Misura.findAllBySensore(sensor), misuraCount: Misura.count()]
    }

    def downloadSampleExcel() {
        response.setContentType('application/vnd.ms-excel')
        response.setHeader('Content-Disposition', 'Attachment;Filename="misure.xls"')
        WritableWorkbook workbook = Workbook.createWorkbook(response.outputStream)
        WritableSheet sheet1 = workbook.createSheet("Misure", 0)
        List<Sensore> listaSensori = Sensore.findAll()

        for (int i = 0; i < listaSensori.size(); i++) {
            sheet1.addCell(new Label(i, 0, listaSensori.get(i).toString()))
            def counterMisure = 1

            List<Misura> listaMisure = Misura.findAllBySensore(listaSensori.get(i))
            for (Misura misura : listaMisure) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
                sheet1.addCell(new Label(i, counterMisure, sdf.format(misura.data) + ";" + misura.valore))
                counterMisure++
            }
        }


        workbook.write();
        workbook.close();
    }
}
