package iot2



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class SogliaAvvisoController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond SogliaAvviso.list(params), model:[sogliaAvvisoInstanceCount: SogliaAvviso.count()]
    }

    def show(SogliaAvviso sogliaAvvisoInstance) {
        respond sogliaAvvisoInstance
    }

    def create() {
        respond new SogliaAvviso(params)
    }

    @Transactional
    def save(SogliaAvviso sogliaAvvisoInstance) {
        if (sogliaAvvisoInstance == null) {
            notFound()
            return
        }

        if (sogliaAvvisoInstance.hasErrors()) {
            respond sogliaAvvisoInstance.errors, view:'create'
            return
        }

        sogliaAvvisoInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'sogliaAvviso.label', default: 'SogliaAvviso'), sogliaAvvisoInstance.id])
                redirect sogliaAvvisoInstance
            }
            '*' { respond sogliaAvvisoInstance, [status: CREATED] }
        }
    }

    def edit(SogliaAvviso sogliaAvvisoInstance) {
        respond sogliaAvvisoInstance
    }

    @Transactional
    def update(SogliaAvviso sogliaAvvisoInstance) {
        if (sogliaAvvisoInstance == null) {
            notFound()
            return
        }

        if (sogliaAvvisoInstance.hasErrors()) {
            respond sogliaAvvisoInstance.errors, view:'edit'
            return
        }

        sogliaAvvisoInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'SogliaAvviso.label', default: 'SogliaAvviso'), sogliaAvvisoInstance.id])
                redirect sogliaAvvisoInstance
            }
            '*'{ respond sogliaAvvisoInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(SogliaAvviso sogliaAvvisoInstance) {

        if (sogliaAvvisoInstance == null) {
            notFound()
            return
        }

        sogliaAvvisoInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'SogliaAvviso.label', default: 'SogliaAvviso'), sogliaAvvisoInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'sogliaAvviso.label', default: 'SogliaAvviso'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
