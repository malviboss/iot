package iot2



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class LocalizzazioneController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond Localizzazione.list(params), model:[localizzazioneInstanceCount: Localizzazione.count()]
    }

    def show(Localizzazione localizzazioneInstance) {
        respond localizzazioneInstance
    }

    def create() {
        respond new Localizzazione(params)
    }

    @Transactional
    def save(Localizzazione localizzazioneInstance) {
        if (localizzazioneInstance == null) {
            notFound()
            return
        }

        if (localizzazioneInstance.hasErrors()) {
            respond localizzazioneInstance.errors, view:'create'
            return
        }

        localizzazioneInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'localizzazione.label', default: 'Localizzazione'), localizzazioneInstance.id])
                redirect localizzazioneInstance
            }
            '*' { respond localizzazioneInstance, [status: CREATED] }
        }
    }

    def edit(Localizzazione localizzazioneInstance) {
        respond localizzazioneInstance
    }

    @Transactional
    def update(Localizzazione localizzazioneInstance) {
        if (localizzazioneInstance == null) {
            notFound()
            return
        }

        if (localizzazioneInstance.hasErrors()) {
            respond localizzazioneInstance.errors, view:'edit'
            return
        }

        localizzazioneInstance.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'Localizzazione.label', default: 'Localizzazione'), localizzazioneInstance.id])
                redirect localizzazioneInstance
            }
            '*'{ respond localizzazioneInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(Localizzazione localizzazioneInstance) {

        if (localizzazioneInstance == null) {
            notFound()
            return
        }

        localizzazioneInstance.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'Localizzazione.label', default: 'Localizzazione'), localizzazioneInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'localizzazione.label', default: 'Localizzazione'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
