import iot2.Sensore
import iot2.Tipi



class BootStrap {

    def init = { servletContext ->

        Sensore.list().each { sensor ->
            if (sensor.frequenzaAvviso == null) {
                sensor.frequenzaAvviso = 1
                sensor.save()
            }
        }
        if (Tipi.list().isEmpty()) {
            new Tipi(tipo: "String").save()
            new Tipi(tipo: "Double").save()
            new Tipi(tipo: "Integer").save()
            new Tipi(tipo: "Boolean").save()
        }
    }
    def destroy = {

    }
}
