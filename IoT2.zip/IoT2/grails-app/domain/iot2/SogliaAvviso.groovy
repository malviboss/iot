package iot2

class SogliaAvviso {
    Sensore sensore
    Double valorePersonalizzato
    String descrizione

    static constraints = {
        valorePersonalizzato (nullable: true)
    }
}
