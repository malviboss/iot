package iot2

class Localizzazione {
    String edificio
    String piano
    String aula
    String descrizione

    static constraints = {
        descrizione(nullable: true)
        edificio(nullable: false)
        piano(nullable: false)
        aula(nullable: false)

    }

    String toString() {
        if (descrizione != null)
            return edificio + " " + piano + " " + aula + " " + descrizione
        else
            return edificio + " " + piano + " " + aula
    }
}
