package iot2

class TipoMisura {
    Tipi dataType
    String nomeMisura

    static constraints = {
        nomeMisura(nullable: false)
    }

    String toString() {
        return nomeMisura
    }
}
