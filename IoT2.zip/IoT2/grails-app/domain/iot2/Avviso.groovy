package iot2
class Avviso {
    Sensore sensore
    String avviso
    String descrizione
    Boolean letto

    static constraints = {
        descrizione(nullable: false)
    }

    String toString() {
        return descrizione
    }
}
