package iot2

class Sensore {
    String nomeSensore
    TipoMisura tipoMisura
    Localizzazione localizzazione
    Double min
    Double max
    Long tempoCampionamento = 0
    String uuid
    Integer frequenzaAvviso = 1


    static constraints = {
        nomeSensore (nullable: false)
        tempoCampionamento (nullable: true)

        /*        max (nullable: true, validator: {
                val, obj ->
                val > (obj.min)
            })
            min(nullable: true, validator: {
                val, obj ->
                val < (obj.max)
            })
*/

        max (nullable: true, validator: {val, obj ->
            if (val!=null && obj.min !=null)
            val > obj.min
        })
        min (nullable: true, validator: {val, obj ->
            if (val!=null && obj.max !=null)
                val < obj.max
        })

        frequenzaAvviso ( validator: {val, obj ->
                val >= 0
        })



        uuid(unique: true)

    }

    String toString() {
        if (tipoMisura != null && tipoMisura.nomeMisura != null)
            return nomeSensore + " " + tipoMisura.nomeMisura + " " + localizzazione
        else
            return nomeSensore+ " " + localizzazione
    }
}
