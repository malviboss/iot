package iot2


class Misura {
    Date data
    String valore
    TipoMisura tipoMisura
    Sensore sensore


    static constraints = {

    }

    String toString() {
        return valore
    }
}
