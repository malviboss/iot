package iot2

class Settings {
    Integer frequenzaAvviso = 1

    static constraints = {

    }
}
