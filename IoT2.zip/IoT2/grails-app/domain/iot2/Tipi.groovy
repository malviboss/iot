package iot2

class Tipi {
    String tipo

    static constraints = {
    }

    String toString() {
        return tipo
    }
}
