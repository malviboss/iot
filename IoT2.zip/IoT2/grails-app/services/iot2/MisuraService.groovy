package iot2

import grails.transaction.Transactional
import groovy.json.*



@Transactional

class MisuraService {

    def serviceMethod() {

    }

    def trovaMisure(Sensore sensoreInstance){
        def trovati
        trovati = Misura.executeQuery("from Misura where sensore = :sensore", [sensore: sensoreInstance])
        println("TROVATE MISURE DEL SENSORE!" + trovati.size())

        return  trovati

    }

    def leggiGateway(String urlz){
        def cookieToReturn


        //-------------
        CookieManager cookieManager = new CookieManager();
        CookieHandler.setDefault(cookieManager);

        URL url = new URL(urlz);

        URLConnection connecton = url.openConnection();
        connecton.getContent();

        List<HttpCookie> cookies = cookieManager.getCookieStore().getCookies();
        for (HttpCookie cookie : cookies) {
            cookieToReturn = cookie

        }

        return cookieToReturn


        //---------------

        /*
        def get = new URL(urlz).openConnection();
        String sessionId = get.getHeaderField("JSESSIONID")
        println "COOKIE -> ${sessionId}"
        def getRC = get.getResponseCode()
        println("O ALTRO $getRC")
        if (getRC.equals(200)) {
            println "+++++++***********HABEMUNS CONNESSIONE"
            return sessionId
        } else {
            print "NO CONNECTION NO PARTY"
            return false
        }
*/
    }


    def leggiConnessione(def url, def sessionid, def cookie){
        def get = new URL(url).openConnection()
        get.setRequestProperty(sessionid, cookie.getValue())
        def getRC = get.getResponseCode()
        if (getRC.equals(200)) {
            return true
        } else {
            print "NO CONNECTION NO PARTY"
            return false
        }

    }

    def trovaMisureDoppie(Sensore sensore, Date data, def valore){
        Boolean trovato
        def misureTrovate = Misura.executeQuery("from Misura where sensore = :sensore and data = :data and valore = :valore", [sensore:sensore, data:data, valore:valore])
        if (!misureTrovate.isEmpty())
            trovato = true
        else
            trovato = false
        return trovato
    }

    def trovaUltimaMisura(Sensore sensore, def valore){
        Misura misuraPrecedente = null
        def misureTrovate = Misura.executeQuery("from Misura where sensore = :sensore order by id desc ", [sensore:sensore])
        if (!misureTrovate.isEmpty())
            misuraPrecedente = misureTrovate.get(0)
        return misuraPrecedente
    }

    def frequenzaAvviso(Sensore sensore, Misura misura ){
        Boolean trovato
        def avvisiDoppiTrovati = Misura.executeQuery("from Misura where sensore = :sensore and valore = valore",[sensore:sensore , valore: misura.valore])
        def size = avvisiDoppiTrovati.toList().size()
        def frequenza = sensore.frequenzaAvviso
        if (size >= frequenza)
            trovato = true
        else
            trovato = false
        return trovato

    }
}
