package iot2

import grails.transaction.Transactional

@Transactional
class SensoreService {

    def serviceMethod() {

    }

    def trovaSensore(String sensore){
        def trovati
        trovati = Sensore.executeQuery("from Sensore where nomeSensore = :sensor", [sensor: sensore])
        return  trovati
        //Query qry = session.createQuery ("from Sensore where nomeSensore = :sensor")
        //qry.setParameter("sensor",sensore)
        //List<Sensore> listaSensori = qry.list()
       /* */
    }

    def trovaSensoreUuid(String uuid){
        def trovati
        trovati = Sensore.executeQuery("from Sensore where uuid = :uuid", [uuid: uuid])
        return  trovati
        //Query qry = session.createQuery ("from Sensore where nomeSensore = :sensor")
        //qry.setParameter("sensor",sensore)
        //List<Sensore> listaSensori = qry.list()
        /* */
    }


}
