package iot2

import grails.transaction.Transactional
import iot2.Sensore

@Transactional
class AvvisoService {

    def serviceMethod() {

    }



    def trovaAvviso(iot2.Sensore sensore){
        def trovati
        trovati = Avviso.findAllBySensore(sensore)
        println("TROVATI AVVISI DEL SENSORE ${trovati.size()}")

        return  trovati
        //Query qry = session.createQuery ("from Sensore where nomeSensore = :sensor")
        //qry.setParameter("sensor",sensore)
        //List<Sensore> listaSensori = qry.list()
        /* */
    }

    def trovaSoglie(iot2.Sensore sensore){
        def listaSoglie = SogliaAvviso.findAllBySensore(sensore)
        return listaSoglie
    }
}
