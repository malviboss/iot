package iot2

import grails.transaction.Transactional

@Transactional
class TipoMisuraService {

    def serviceMethod() {

    }


    def trovaTipoMisura(String nome) {
        def trovati
        trovati = TipoMisura.executeQuery("from TipoMisura where nomeMisura = :tipo", [tipo: nome])
        println("TROVATI TIPI!" + trovati.size())

        return trovati
        //Query qry = session.createQuery ("from Sensore where nomeSensore = :sensor")
        //qry.setParameter("sensor",sensore)
        //List<Sensore> listaSensori = qry.list()
        /* */
    }

    def trovaTipoMisuraUuid(def uuid) {
        def trovati
        trovati = TipoMisura.executeQuery("from TipoMisura where nomeMisura = :tipo", [tipo: nome])
        println("TROVATI TIPI!" + trovati.size())

        return trovati
        //Query qry = session.createQuery ("from Sensore where nomeSensore = :sensor")
        //qry.setParameter("sensor",sensore)
        //List<Sensore> listaSensori = qry.list()
        /* */
    }
}
